function print( _title, _color ){
	
	if _color == undefined _color = c_white;
	array_push( console, { title : _title, color : _color } );
	
	if array_length(console) > 30 {
	array_delete(console,0,1);
	}
	
}