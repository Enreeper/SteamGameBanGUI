function link_extract_api_key(__LINK_TEXT){

	if (string_length(__LINK_TEXT) != 32) {
	return -1;	
	}
	
	var _allowed = "0123456789abcdefABCDEF";
	for (var i = 1; i < 32; i++) {
	
		var _char = string_char_at(__LINK_TEXT, i);
		if (string_pos(_char, _allowed) == 0) {
		return -1;
		}
	
	}
	

return __LINK_TEXT;
	
}