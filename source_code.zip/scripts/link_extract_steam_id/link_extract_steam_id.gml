function link_extract_steam_id(_input_string){

	// extract numbers only out of the link
	var _extracted_digits = string_digits(_input_string);

	// Check if its an valid steam id
	if (string_length(_extracted_digits) == 17 && string_copy(_extracted_digits, 1, 4) == "7656") {
	return _extracted_digits;	
	}
	
	else return -1;
	
	
}