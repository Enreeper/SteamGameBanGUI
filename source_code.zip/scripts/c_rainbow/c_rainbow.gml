function c_rainbow() {
var _c_rainbow = make_color_hsv((current_time/100) mod 255,255,255);
return _c_rainbow;
}