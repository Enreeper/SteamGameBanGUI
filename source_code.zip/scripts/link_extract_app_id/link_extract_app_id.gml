function link_extract_app_id(__LINK_STRING){
	
	// extract part before and after "/app/" 
	var _pos = string_pos("/app/", __LINK_STRING);
	if (_pos > 0) {
	
		var _sub = string_delete(__LINK_STRING, 1, _pos+4);
		
		var _slash_pos = string_pos("/", _sub);
		if (_slash_pos > 0) {
			_sub = string_copy(_sub, 1, _slash_pos - 1);
		}
		
		// extract digits only (failsafe)
		var _app_id = string_digits(_sub);
		if (_app_id != "") {
		return _app_id;	
		}
	
	}
	
	return -1;

}