switch (state) {
	
	// API KEY Input
    case "api_key":
		
		var __STEAM_API_KEY = link_extract_api_key(command_state);
	
		if __STEAM_API_KEY != -1 {
        API_KEY = __STEAM_API_KEY;
		
		print( "API_KEY: "+string(API_KEY), c_rainbow() );
		print("", c_gray );
		print("// Please enter the AppID", c_gray );
		
		state = "api_appid";
		}
		
		else {
		print("", c_gray );
		print("ERROR: Invallid API-KEY, please enter an valid 32 digit API-KEY", c_red );
		}
    break;
	
	// APPID Input
	case "api_appid":
		
		var __STEAM_APPID = link_extract_app_id(command_state);
	
		if __STEAM_APPID != -1 {
        APPID = __STEAM_APPID;
		print( "APPID: "+string(APPID), c_rainbow() );
		print("", c_gray );
		
		print("// Please enter the SteamID64 of the target User", c_gray );
		state = "api_userid";
		}
		
		else {
		print("", c_gray );
		print("ERROR: Invallid AppID, please enter an valid Steam-AppID", c_red );
		}
    break;
	
		// APPID Input
	case "api_userid":
	
		// Formating Check
		var __STEAMID64 = link_extract_steam_id(command_state);
		
		// Valid Steam ID
		if __STEAMID64 != -1 {
        USERID = __STEAMID64;
		print( "USERID: "+string(__STEAMID64), c_rainbow() );
		print("", c_gray );
		
		print("// What command would you like to execute ?", c_gray );
		print("1: Report Profile", c_gray );
		print("2: Ban Profile", c_gray );
		print("3: Unban Profile", c_gray );
		
		state = "api_model_choose";
		}
		
		// Invalid SteamID
		else {
		print("", c_gray );
		print("ERROR: Invallid SteamID, please enter an STEAMID64", c_red );
		}
    break;
	
	
	
	// API Model Input
	case "api_model_choose":
	
		switch (command_state) {
			
		    case "1":
		        print("[REPORT MODE]", c_rainbow() );
				
				__URL_PARAMS = "?key=" +string(API_KEY)+ "&appid=" +string(APPID)+ "&steamid=" +string(USERID);
				__REPORT_URL = http_post_string("https://partner.steam-api.com/ICheatReportingService/ReportPlayerCheating/v1/", __URL_PARAMS );
				state = "report";
		    break;
			
			case "2":
		        
				if REPORTID == undefined {
				print("// Make sure you have already reported this profile beforehand otherwise this API call wont work.", c_gray );
				event_user(2);
				}
				else {
				print("[BAN MODE]", c_rainbow() );
				print("", c_gray );
				print("// enter the description for the ban", c_gray );
				
				state = "cheat_desc_input";
				}
				
		    break;
			
			case "3":
		       print("[UNBAN MODE]", c_rainbow() );
				__URL_PARAMS = "?key=" +string(API_KEY)+ "&steamid=" +string(USERID)+ "&appid=" +string(APPID);
				__REPORT_URL = http_post_string("https://partner.steam-api.com/ICheatReportingService/RemovePlayerGameBan/v1/", __URL_PARAMS );
				
				state = "unban"
		    break;
				
		    default:
		        print("Invalid selection", c_red);
		    break;
		}
	
    break;
	
	// Cheatdesc Input
	case "cheat_desc_input":
		
		CHEATDESC = command_state;
	
		__URL_PARAMS = "?key=" +string(API_KEY)+ "&steamid=" +string(USERID) + "&appid=" +string(APPID)+ "&reportid=" +string(REPORTID) + "&cheatdescription=" +string(CHEATDESC)+ "&duration=" +string(BANDURRATION)+"&delayban=false"
		__REPORT_URL = http_post_string("https://partner.steam-api.com/ICheatReportingService/RequestPlayerGameBan/v1/", __URL_PARAMS );
		
		state = "banning";
    break;
	
	//	// APPID Input
	//case "ban_durration":
		
	//	BANDURRATION = command_state;
	
	//	__URL_PARAMS = "?key=" +string(API_KEY)+ "&steamid=" +string(USERID) + "&appid=" +string(APPID)+ "&reportid=" +string(REPORTID) + "&cheatdescription=" +string(CHEATDESC)+ "&duration=" +string(BANDURRATION)+"&delayban=false"
	//	__REPORT_URL = http_post_string("https://partner.steam-api.com/ICheatReportingService/RequestPlayerGameBan/v1/", __URL_PARAMS );
		
	//	state = "banning";
    //break;
		
    default:
        print("CRITICAL ERROR: programm has become unstable please exit.", c_red);
     break;
}