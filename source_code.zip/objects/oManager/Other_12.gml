print("", c_gray );
		
		print("// What command would you like to execute ?", c_gray );
		print("1: Report Profile", c_gray );
		print("2: Ban Profile", c_gray );
		print("3: Unban Profile", c_gray );
		
		state = "api_model_choose";