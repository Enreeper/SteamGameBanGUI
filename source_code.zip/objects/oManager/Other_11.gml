switch (command_state) {

		
    default:
        print("unnknown command ("+string(command_state)+")", c_red);
        break;
		
}

command_state = "";