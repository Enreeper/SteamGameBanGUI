var r_str = "null";
if (ds_map_find_value(async_load, "id") == __REPORT_URL)
{
    if (ds_map_find_value(async_load, "status") == 0)
    {	
		print("HTTP_GET", c_white );
        r_str = ds_map_find_value(async_load, "result");
		print("result: "+string(r_str), c_white );
		
		if string_starts_with(r_str, "{") {
			
			if state == "report" {
				
				if REPORTID == undefined {
				
					// ReportID
					var r = json_parse(async_load[? "result"]);
					REPORTID = r.response.reportid;
					print("REPORTID: "+string(REPORTID), c_rainbow() );
					
					if REPORTID == undefined {
					print("error: something went wrong :(", c_red );	
					event_user(2);
					}
					else {
					print("User can now be applied an Game Ban", c_rainbow() );	
					event_user(2);
					}
				
				}
				
				else {
				print("User has allready been reported this session!", c_yellow );
				event_user(2);
				}
				
			}
			
			if state == "banning" {
			var r = json_parse(async_load[? "result"]);
				
				if struct_names_count(r) > 0 {
					print("Sucsesfully added Game Ban :D", c_rainbow() );
					event_user(2);
				}

				else {
				print(r.response.steamid );
				print("error: something went wrong :(", c_red );
				event_user(2);
				}
			}
			
			if state = "unban" {

				var r = json_parse(async_load[? "result"]);	
				
				if struct_names_count(r) > 0 {
				print("Sucsesfully removed Game Ban :D", c_rainbow() );
				event_user(2);
				}
				else {
				print("error: something went wrong :(", c_red );
				event_user(2);
				}
			}
		}
			
		else {
		event_user(2);	
		}
		
    }
}