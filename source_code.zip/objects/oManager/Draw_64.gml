var dist = font_get_size(font)*2;
for (var i = 0; i < array_length(console); ++i) {
    
	draw_set_color(console[i].color);
	draw_text( 8, 8 +dist*i, console[i].title );
	
}
	
	draw_set_color(c_rainbow());
	draw_text( 8, 8 +dist* array_length(console)+1, user_input + indicator );