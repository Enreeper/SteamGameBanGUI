window_set_caption("SGB API")

// Init Main
console = [];
user_input = "";
indicator = " ";
state = "";
command_state = "";

// Init Vars
API_KEY = "";
APPID = "";
USERID = "";
REPORTID = undefined;
CHEATDESC = "cheater";
BANDURRATION = 0;

// Text-Input Indicator
alarm[0] = room_speed/4;

draw_set_font(font);
draw_set_halign(fa_left);

// Check if Client is connected to the Internet
if !os_is_network_connected() {
print("ERROR, OS is not network connected.", c_red );	
}

// CASE: Sucsess, Has Internet :D
else {
	
	// Programm ready
	print("Steam Game Ban API | v1.1");
	state = "api_key";	

	// Check for pre-defined keys
	ini_open(working_directory + "metadata.ini");
	var _API_KEY = ini_read_string("main", "WEB_API_KEY", "");
	var _APP_ID  = ini_read_string("main", "STEAM_APP_ID", "");
	ini_close();
	
	// Predefined Key
	if _API_KEY != "" {
	command_state = _API_KEY;
	event_user(0);
	
		if _APP_ID != "" {
		command_state = _APP_ID;
		event_user(0);
		}
	}
	
	// No Predefined Key
	else {
	print("// Please enter your API PUBLISHER key", c_gray);		
	}
}