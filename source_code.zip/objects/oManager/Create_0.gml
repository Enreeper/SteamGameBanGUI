window_set_caption("SGB API | SIMPLE EDITION")

console = [];
user_input = "";
indicator = " ";
state = "";
command_state = "";

// vars
API_KEY = "";
APPID = "";
USERID = "";
REPORTID = undefined;
CHEATDESC = "cheater";
BANDURRATION = 0;

alarm[0] = room_speed/4;

draw_set_font(font);
draw_set_halign(fa_left);

if !os_is_network_connected() {
print("ERROR, OS is not network connected.", c_red );	
}
else {
print("Steam Game Ban API | SIMPLE EDITION");	
print("// Please enter your API PUBLISHER key", c_gray);	
state = "api_key";

}