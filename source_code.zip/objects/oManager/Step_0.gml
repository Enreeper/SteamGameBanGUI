user_input = keyboard_string;

// copy paste
if keyboard_check(vk_control) && keyboard_check_pressed(ord("V")) || mouse_check_button_released(mb_right) {
	keyboard_string = string_insert( clipboard_get_text(), keyboard_string, string_length(keyboard_string) )
}

// send command
if keyboard_check_pressed(vk_enter) {
	
	command_state = keyboard_string;
	event_user(0);
	keyboard_string = "";
	
}