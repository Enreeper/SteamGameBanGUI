alarm[0] = room_speed/4;
if indicator == " " indicator = "|" else indicator = " ";